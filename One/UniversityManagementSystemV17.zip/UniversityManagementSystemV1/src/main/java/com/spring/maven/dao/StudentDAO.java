package com.spring.maven.dao;

import com.spring.maven.dao.impl.IStudentDAO;
import com.spring.maven.model.Student;
import java.util.List;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author sany5
 */
@Repository(value = "studentDAO")
@Transactional
public class StudentDAO implements IStudentDAO {

    @Autowired
    SessionFactory sessionFactory;

    @Override
    public Student save(Student s) {
        sessionFactory.getCurrentSession().save(s);
        sessionFactory.getCurrentSession().flush();
        return s;
    }

    @Override
    public Student update(Student t) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Student delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Student> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Student getById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
