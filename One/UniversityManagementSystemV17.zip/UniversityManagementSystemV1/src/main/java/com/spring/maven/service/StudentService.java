/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.spring.maven.service;

import com.spring.maven.dao.StudentDAO;
import com.spring.maven.model.Employee;
import com.spring.maven.model.Student;
import com.spring.maven.service.impl.IStudentService;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

/**
 *
 * @author sany5
 */
@Service(value = "studentService")
public class StudentService implements IStudentService{
    @Autowired
    StudentDAO studentDAO;

    @Override
    public Student save(HttpServletRequest request) {
        Map<String, String[]> map = request.getParameterMap();
       Student s = new Student();
        s.setSid(Integer.parseInt(map.get("sid")[0]));
        s.setName(map.get("name")[0]);
        s.setEmail(map.get("email")[0]);
        s.setPhone(map.get("phone")[0]);
        s.setAddress(map.get("name")[0]);
        s.setfName(map.get("fname")[0]);
        s.setmName(map.get("mname")[0]);
        s.setDob(map.get("dob")[0]);
        s.setReligion(map.get("religion")[0]);
        s.setBloodGroup(map.get("bloodgroup")[0]);
       
       return s;
    }

    @Override
    public Student update(HttpServletRequest request) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Student delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Student> getAll() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Student getById(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
    
}
