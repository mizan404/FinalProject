/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.sr.spring.hospital.controller.impl;

import com.sr.spring.hospital.common.IController;

/**
 *
 * @author Siddiquer Rahman
 */
public interface IReceptionControllerImpl extends IController{
    
}
